### iubenda-test

Hi, this is my test. As requested I've used store, for the logic of form the BaseInput set data directly to the store and not through v-model. Is not better, but is just to create all app logic inside store.

For the test i used Cypress and i created test for the major tasks of the app.

Like Linter i used the essential config

The time that i have used for test is around the 8 hours.

## Project setup

```
yarn install
```

### Compiles and hot-reloads for development

```
yarn serve
```

### Compiles and minifies for production

```
yarn build
```

### Run your end-to-end tests

```
yarn test:e2e
```

### Lints and fixes files

```
yarn lint
```
