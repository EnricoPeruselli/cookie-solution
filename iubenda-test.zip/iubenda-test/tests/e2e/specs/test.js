// https://docs.cypress.io/api/table-of-contents

// Test for Banner Scroll policy
describe('Test for Banner Scroll policy', () => {
  it('Visits the app root url', () => {
    cy.visit('/')
  })
  it('set true options and display messagge error', () => {
    cy.get('.consentByScroll').check()
    cy.get('.warning-scroll').contains('Your selected settings are not compliant with laws in France and Italy')
  })
  it('set false options and remove messagge error', () => {
    cy.get('.consentByScroll').uncheck()
    cy.get('.warning-scroll').should('not.exist')
  })
  it('reset true options and display messagge error', () => {
    cy.get('.consentByScroll').check()
    cy.get('.warning-scroll').contains('Your selected settings are not compliant with laws in France and Italy')
  })
  it('change country to us and check if the messagge was remove', () => {
    cy.get('.targetCountries').check(['US'])
    cy.get('.warning-scroll').should('not.exist')
  })
})

// Test for Banner Purpose policy
describe('Test for Banner Purpose policy', () => {
  it('Visits the app root url', () => {
    cy.visit('/')
  })
  it('set true options and display messagge error', () => {
    cy.get('.perPurposeConsent').check()
    cy.get('.warning-purpose').contains('Your selected settings are not compliant with laws in France')
  })
  it('set false options and remove messagge error', () => {
    cy.get('.perPurposeConsent').uncheck()
    cy.get('.warning-purpose').should('not.exist')
  })
  it('reset true options and display messagge error', () => {
    cy.get('.perPurposeConsent').check()
    cy.get('.warning-purpose').contains('Your selected settings are not compliant with laws in France')
  })
  it('change country to us and check if the messagge was remove', () => {
    cy.get('.targetCountries').check(['US'])
    cy.get('.warning-purpose').should('not.exist')
  })
})

// Test for Banner Optional policy
describe('Test for Banner Optional policy', () => {
  it('Visits the app root url', () => {
    cy.visit('/')
  })
  it('Set country to EU', () => {
    cy.get('.targetCountries').check(['EU'])
  })
  it('reset condition', () => {
    cy.get('.acceptButtonDisplay').uncheck()
    cy.get('.rejectButtonDisplay').uncheck()
    cy.get('.closeButtonDisplay').uncheck()
    cy.get('.closeButtonRejects').uncheck()
  })
  it('Set first condition error | closeButtonDisplay = true and closeButtonRejects = false and test if the warning message was display correctly', () => {
    cy.get('.closeButtonDisplay').check()
    cy.get('.closeButtonRejects').uncheck()
    cy.get('.warning-options').contains('Your selected settings are not compliant with laws in Italy')
  })
  it('reset condition', () => {
    cy.get('.acceptButtonDisplay').uncheck()
    cy.get('.rejectButtonDisplay').uncheck()
    cy.get('.closeButtonDisplay').uncheck()
    cy.get('.closeButtonRejects').uncheck()
  })
  it('Set second condition error | rejectButtonDisplay = false and closeButtonRejects = false and test if the warning message was display correctly', () => {
    cy.get('.rejectButtonDisplay').uncheck()
    cy.get('.closeButtonRejects').uncheck()
    cy.get('.warning-options').contains('Your selected settings are not compliant with laws in Italy')
  })
  it('reset condition', () => {
    cy.get('.acceptButtonDisplay').uncheck()
    cy.get('.rejectButtonDisplay').uncheck()
    cy.get('.closeButtonDisplay').uncheck()
    cy.get('.closeButtonRejects').uncheck()
  })
  it('Set third condition error | rejectButtonDisplay = true and closeButtonRejects = true and closeButtonDisplay = false and test if the warning message was display correctly', () => {
    cy.get('.rejectButtonDisplay').check()
    cy.get('.closeButtonRejects').check()
    cy.get('.closeButtonDisplay').uncheck()
    cy.get('.warning-options').contains('Your selected settings are not compliant with laws in Italy')
  })
  // Test unit with US country selected
  it('Set country to US', () => {
    cy.get('.targetCountries').check(['US'])
  })
  it('Set first condition error with US COUNTRY SELECTED, expect that error message not show', () => {
    cy.get('.closeButtonDisplay').check()
    cy.get('.closeButtonRejects').uncheck()
    cy.get('.warning-options').should('not.exist')
  })
  it('reset condition', () => {
    cy.get('.acceptButtonDisplay').uncheck()
    cy.get('.rejectButtonDisplay').uncheck()
    cy.get('.closeButtonDisplay').uncheck()
    cy.get('.closeButtonRejects').uncheck()
  })
  it('Set second condition error with US COUNTRY SELECTED, expect that error message not show', () => {
    cy.get('.rejectButtonDisplay').uncheck()
    cy.get('.closeButtonRejects').uncheck()
    cy.get('.warning-options').should('not.exist')
  })
  it('reset condition', () => {
    cy.get('.acceptButtonDisplay').uncheck()
    cy.get('.rejectButtonDisplay').uncheck()
    cy.get('.closeButtonDisplay').uncheck()
    cy.get('.closeButtonRejects').uncheck()
  })
  it('Set third condition error with US COUNTRY SELECTED, expect that error message not show', () => {
    cy.get('.rejectButtonDisplay').check()
    cy.get('.closeButtonRejects').check()
    cy.get('.closeButtonDisplay').uncheck()
    cy.get('.warning-options').should('not.exist')
  })
})
