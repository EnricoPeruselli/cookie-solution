import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    // ConfigDefault Section, this data manage the banner
    configDefault: {
      targetCountries: 'EU', // Possible values: 'EU', 'US', 'world'
      gdpr: true,
      ccpa: false,

      consentByScroll: false,
      perPurposeConsent: false,

      banner: {
        acceptButtonDisplay: false, // visibility of the Accept button
        rejectButtonDisplay: false, // visibility of the Reject button
        closeButtonDisplay: true, // visibility of the Close button
        closeButtonRejects: false, // clicking the Close button should accept (`false`) or reject (`true`) the consent
        title: 'Notice' // Text field that will change the displayed title of the banner
      }
    },
    // warning message to show if the config produce some error
    warningMessage: null,
    warningMessageScroll: null,
    warningMessagePurpose: null,
    // data that disable the save button, true every time that options change
    dataChange: false,
    // data that help to reload content
    counter: 0,
    // data that need for show or unshow skeleton
    loader: false,
    // ConfigBanner Section, this data manage all UI banner state
    configBanner: [
      {
        title: 'Optional Config',
        checks: [
          {
            title: 'Accept Button',
            name: 'acceptButtonDisplay',
            value: false,
            type: 'checkbox'
          },
          {
            title: 'Reject Button',
            name: 'rejectButtonDisplay',
            value: false,
            type: 'checkbox'
          },
          {
            title: 'Close button display',
            name: 'closeButtonDisplay',
            value: true,
            type: 'checkbox'
          },
          {
            title: 'Close button reject',
            name: 'closeButtonRejects',
            value: false,
            type: 'checkbox'
          }
        ]
      }
    ],
    // ConfigControl Section, this data manage all control options
    configControl: [
      {
        title: 'Target countries',
        checks: [
          {
            title: 'Wordlwide',
            name: 'targetCountries',
            value: 'world',
            type: 'radio'
          },
          {
            title: 'US users only',
            name: 'targetCountries',
            value: 'US',
            type: 'radio'
          },
          {
            title: 'EU users only',
            name: 'targetCountries',
            value: 'EU',
            type: 'radio'
          }
        ]
      },
      {
        title: 'Legislation',
        checks: [
          {
            title: 'GDPR',
            value: true,
            name: 'gdpr',
            type: 'checkbox'
          },
          {
            title: 'CCPA',
            value: false,
            name: 'ccpa',
            type: 'checkbox'
          }
        ]
      },
      {
        title: 'Consent',
        checks: [
          {
            title: 'Consent by scroll',
            value: false,
            name: 'consentByScroll',
            type: 'checkbox'
          },
          {
            title: 'Per purpose consent',
            value: false,
            name: 'perPurposeConsent',
            type: 'checkbox'
          }
        ]
      }
    ]
  },
  getters: {
  },
  mutations: {
    // mutations that was dispatch from checkrow component, find the correct node by name and set value
    SET_DATA (state, payload) {
      state.configDefault[payload.name] = payload.value
    },
    SET_DATA_BANNER (state, payload) {
      state.configDefault.banner[payload.name] = payload.value
    },
    SET_WARNING_MESSAGE (state) {
      // base data
      const eu = state.configDefault.targetCountries === 'EU'
      const world = state.configDefault.targetCountries === 'world'
      const closeButtonDisplay = state.configDefault.banner.closeButtonDisplay
      const closeButtonRejects = state.configDefault.banner.closeButtonRejects
      const rejectButtonDisplay = state.configDefault.banner.rejectButtonDisplay
      const consentScroll = state.configDefault.consentByScroll
      const consentPurpose = state.configDefault.perPurposeConsent
      // conditions
      // conditions banner policy
      const conditionsBanner = [closeButtonDisplay && !closeButtonRejects, !rejectButtonDisplay && !closeButtonRejects, rejectButtonDisplay && closeButtonRejects && !closeButtonDisplay]
      // conditions bannel scroll
      const conditionsScroll = [consentScroll]
      // conditions banner purpose
      const conditionsPurpose = [consentPurpose]
      // action
      // check if in conditionsBanner there is a true state
      const trueState = (element) => element === true
      // check if in conditionsBanner there is a false state
      const falseState = (element) => element === false
      // Options banner conditions
      if (eu || world) {
        // manage banner conditions
        if (conditionsBanner.some(trueState)) {
          state.warningMessage = 'Your selected settings are not compliant with laws in Italy'
        } else if (!conditionsBanner.every(falseState)) {
          // check if all conditions in array are false and reset messagge
          state.warningMessage = null
        } else {
          state.warningMessage = null
        }
        // manage scroll conditions
        if (conditionsScroll.some(trueState)) {
          state.warningMessageScroll = 'Your selected settings are not compliant with laws in France and Italy'
        } else {
          state.warningMessageScroll = null
        }
        // manage purpose conditions
        if (conditionsPurpose.some(trueState)) {
          state.warningMessagePurpose = 'Your selected settings are not compliant with laws in France'
        } else {
          state.warningMessagePurpose = null
        }
      } else {
        state.warningMessage = null
        state.warningMessageScroll = null
        state.warningMessagePurpose = null
      }
    },
    SET_DATA_CHANGE (state, payload) {
      state.dataChange = payload
    },
    SET_COUNTER (state, payload) {
      state.counter++
    },
    SET_INITIAL_DATA (state) {
      state.configDefault.targetCountries = 'EU'
      state.configDefault.gdpr = true
      state.configDefault.ccpa = false
      state.configDefault.consentByScroll = false
      state.configDefault.perPurposeConsent = false
      state.configDefault.banner.acceptButtonDisplay = false
      state.configDefault.banner.rejectButtonDisplay = false
      state.configDefault.banner.closeButtonDisplay = false
      state.configDefault.banner.closeButtonRejects = false
      state.configDefault.banner.title = 'Notice'
      state.warningMessage = null
      state.warningMessageScroll = null
      state.warningMessagePurpose = null
    },
    SET_LOADER (state, payload) {
      state.loader = payload
    }
  },
  actions: {
    saveData ({ commit, state }) {
      //  simulate HTTP request
      commit('SET_LOADER', true)
      // simulate server response
      setTimeout(() => {
        commit('SET_LOADER', false)
        alert('this would be the data sent' + JSON.stringify(state.configDefault))
      }, '3000')
    }
  },
  modules: {
  }
})
