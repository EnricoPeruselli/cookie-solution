<template>
  <section class="container">
    <BaseTitle :type-of-title="'h1'">
      Configure your Cookie Solution
    </BaseTitle>
    <div class="wrapper">
      <template>
        <TheWrapperControl />
        <TheWrapperBanner />
      </template>
    </div>
  </section>
</template>

<script>
import TheWrapperBanner from '@/components/banner/TheWrapperBanner.vue'
import TheWrapperControl from '@/components/controller/TheWrapperControl.vue'
import BaseTitle from '@/components/master/BaseTitle.vue'
export default {
  name: 'HelloWorld',
  components: {
    TheWrapperBanner,
    TheWrapperControl,
    BaseTitle
  },
  computed: {
    state () {
      return this.$store.state.configDefault
    }
  }
}
</script>
<style>
.wrapper {
  display: grid;
  grid-gap: 1rem;
  grid-template-columns: 40% 60%;
  padding: 1rem;
}
.container h1 {
  text-align: left;
  padding: 1rem;
}
</style>
