<template>
    <div :key="counter">
        <CheckRow :key="option.name" v-for="option in options" :option="option"/>
        <CheckRowBanner :key="option.name" v-for="option in optionsBanner" :option="option"/>
        <section class="warning-wrapper">
          <div v-if="warningMessagePurpose != null" class="warning">
            <BaseText :class-name="'warning-purpose'" :type-of-text="'span'">
              {{warningMessagePurpose}}
            </BaseText>
          </div>
          <div v-if="warningMessageScroll != null" class="warning">
            <BaseText :class-name="'warning warning-scroll'" :type-of-text="'span'">
              {{warningMessageScroll}}
            </BaseText>
          </div>
          <div v-if="warningMessage != null" class="warning">
            <BaseText :class-name="'warning warning-options'" :type-of-text="'span'">
              {{warningMessage}}
            </BaseText>
          </div>
        </section>
    </div>
  </template>

<script>
import CheckRow from '@/components/controller/CheckRow.vue'
import CheckRowBanner from '@/components/controller/CheckRowBanner.vue'
import BaseText from '@/components/master/BaseText.vue'

export default {
  name: 'TheWrapperControl',
  components: {
    CheckRow,
    CheckRowBanner,
    BaseText
  },
  props: {
    msg: String
  },
  computed: {
    config () {
      return this.$store.state.configDefault
    },
    counter () {
      return this.$store.state.counter
    },
    options () {
      return this.$store.state.configControl
    },
    optionsBanner () {
      return this.$store.state.configBanner
    },
    warningMessage () {
      return this.$store.state.warningMessage
    },
    warningMessageScroll () {
      return this.$store.state.warningMessageScroll
    },
    warningMessagePurpose () {
      return this.$store.state.warningMessagePurpose
    }
  }
}
</script>
<style>
  .warning-wrapper {
    margin-top: 2rem;
  }
  .warning {
    background-color: #f5750c;
    margin: 10px;
    padding: 10px 0;
    border-radius: 10px;
    font-size: 12px;
  }
  .warning span {
    color: #fff;
  }
</style>
