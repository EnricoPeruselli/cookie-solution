<template>
    <div class="row-wrapper">
        <BaseTitle :type-of-title="'h4'">
          {{option.title}}
        </BaseTitle>
        <div class="row-wrapper__form">
          <BaseInput :key="i" v-for="(check, i) in option.checks" :data="check" :type="check.type" :name="check.name" @input="saveData" :checked="setChecked(check)" />
        </div>
    </div>
  </template>

<script>
import BaseInput from '@/components/master/BaseInput.vue'
import BaseTitle from '@/components/master/BaseTitle.vue'

export default {
  name: 'TheWrapperControl',
  components: {
    BaseInput,
    BaseTitle
  },
  props: {
    option: {
      type: Object,
      default: () => {}
    }
  },
  methods: {
    saveData (value) {
      // Save data to store, i not use v-model just for set data directly to the store
      this.$store.commit('SET_DATA_BANNER', value)
      // Dispatch warning message check function
      this.$store.commit('SET_WARNING_MESSAGE')
      // Set data change to true
      this.$store.commit('SET_DATA_CHANGE', true)
    },
    // Set the condition to have pre checked the input, the logic is created for this test and can/must be update for forms different to this
    setChecked (check) {
      return check.value === true
    }
  }
}
</script>
