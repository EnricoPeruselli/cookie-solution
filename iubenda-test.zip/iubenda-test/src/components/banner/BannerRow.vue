<template>
    <div class="banner">
      <BaseTitle :type-of-title="'h3'">
        {{data.banner.title}}
      </BaseTitle>
      <BaseText>
        We and selected third parties use cookies or similar technologies for technical purposes and, with your consent, for other purposes. Denying consent may make related features unavailable.
        You can freely give, deny, or withdraw your consent at any time.
        Use the “Accept” button to consent to the use of such technologies.
      </BaseText>
      <section class="banner-actions">
        <BaseButton v-if="dataBanner.banner.rejectButtonDisplay" type-of-class="button-reject">
          Reject
        </BaseButton>
        <BaseButton v-if="dataBanner.banner.acceptButtonDisplay" type-of-class="button-accept">
          Accept
        </BaseButton>
      </section>
    </div>
  </template>

<script>
import BaseTitle from '@/components/master/BaseTitle.vue'
import BaseText from '@/components/master/BaseText.vue'
import BaseButton from '@/components/master/BaseButton.vue'
export default {
  name: 'BannerComponent',
  components: {
    BaseTitle,
    BaseText,
    BaseButton
  },
  props: {
    data: {
      type: Object,
      default: () => {}
    }
  },
  computed: {
    dataBanner () {
      return this.$store.state.configDefault
    }
  }
}
</script>
<style>
  .banner {
    width: auto;
    height: 50%;
    min-height: 300px;
    background: #000;
    color: #fff;
    padding: 2rem;
    text-align: left;
    border-radius: 0 0 30px 30px;
    position: relative;
  }
  .banner-actions {
    display: flex;
    margin-top: 3rem;
    width: 100%;
    align-items: center;
    justify-content: space-around;
  }
</style>
