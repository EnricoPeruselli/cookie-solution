<template>
    <section class="banner-wrapper">
        <div class="banner-wrapper__actions">
          <BaseButton :class="{disable: !dataChange}" @button="resetActions">
            Reset
          </BaseButton>
          <BaseButton :class="{disable: !dataChange}" @button="saveActions">
            Save
          </BaseButton>
        </div>
        <BannerRow :data="dataBanner"/>
      </section>
  </template>

<script>
import BaseButton from '@/components/master/BaseButton.vue'
import BannerRow from '@/components/banner/BannerRow.vue'
export default {
  name: 'TheWrapperBanner',
  components: {
    BaseButton,
    BannerRow
  },
  methods: {
    saveActions () {
      this.$store.dispatch('saveData')
    },
    resetActions () {
      // Reset data to initial state
      this.$store.commit('SET_INITIAL_DATA')
      this.$store.commit('SET_DATA_CHANGE', false)
      this.$store.commit('SET_COUNTER')
    }
  },
  computed: {
    dataChange () {
      return this.$store.state.dataChange
    },
    dataBanner () {
      return this.$store.state.configDefault
    }
  }
}
</script>
<style>
.banner-wrapper__actions {
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
</style>
