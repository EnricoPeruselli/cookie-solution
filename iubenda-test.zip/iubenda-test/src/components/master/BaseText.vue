<template>
      <component :is="typeOfText" :class="className">
          <slot></slot>
      </component>
  </template>
<script>
export default {
  name: 'BaseText',
  props: {
    typeOfText: {
      type: String,
      default: 'p'
    },
    className: {
      type: String,
      default: ''
    }
  }
}
</script>
