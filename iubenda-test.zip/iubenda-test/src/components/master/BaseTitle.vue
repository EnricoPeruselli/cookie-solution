<template>
    <div>
        <component :is="typeOfTitle">
            <slot></slot>
        </component>
    </div>
  </template>
<script>
export default {
  name: 'BaseTitle',
  props: {
    typeOfTitle: {
      type: String,
      default: 'h3'
    }
  }
}
</script>
