<template>
    <div class="field">
      <label v-if="data.title">{{ data.title }}</label>
      <input
        :class="data.name"
        :value="data.value"
        v-bind="$attrs"
        @input="updateValue">
    </div>
  </template>
<script>
export default {
  name: 'BaseInput',
  // inheritAttrs allow to add direct to input the attrs set from father
  inheritAttrs: false,
  props: {
    data: {
      type: Object,
      default: () => {}
    }
  },
  methods: {
    updateValue (event) {
      const objToSend = {
        // if is != to checbox i need to send boolean (event.target.checked)
        value: this.data.type !== 'checkbox' ? event.target.value : event.target.checked,
        name: this.data.name
      }
      this.$emit('input', objToSend)
    }
  }
}
</script>
