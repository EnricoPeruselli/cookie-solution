<template>
        <button @click="emitButton" :class="typeOfClass" class="button">
            <slot></slot>
        </button>
  </template>
<script>
export default {
  name: 'BaseButton',
  props: {
    typeOfClass: {
      type: String,
      default: ''
    }
  },
  methods: {
    emitButton () {
      this.$emit('button')
    }
  }
}
</script>
<style>
.disable {
    opacity: 0.5;
    pointer-events: none;
}
.button.disable:hover {
    cursor: not-allowed;
}
.button {
    min-width: 150px;
    width: auto;
    height: 40px;
    margin: 15px;
    background-color: #2d2d2d;
    color: #fff;
    border: 0;
    border-radius: 10px;
    transition: 0.2s linear;
    font-size: 15px;
    font-weight: bold;
}
.button:hover {
    cursor: pointer;
    opacity: 0.9;
}
.button-reject {
    background-color: #f50c4a;
    color: #fff;
}
.button-accept {
    background-color: #1cc691;
    color: #fff;
}
</style>
