<template>
  <div id="app">
    <Skeleton v-if="loader"/>
    <TheWrapper v-else />
  </div>
</template>

<script>
import TheWrapper from '@/components/TheWrapper.vue'
import Skeleton from '@/components/master/Skeleton.vue'

export default {
  name: 'App',
  components: {
    TheWrapper,
    Skeleton
  },
  computed: {
    loader () {
      return this.$store.state.loader
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
